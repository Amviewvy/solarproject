import { Controller } from '@nestjs/common';

@Controller('control')
export class ControlController {}
